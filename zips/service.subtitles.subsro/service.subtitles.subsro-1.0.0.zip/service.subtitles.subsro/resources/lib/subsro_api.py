# -*- coding: utf-8 -*-
"""
subs.ro API client for Kodi subtitle addon.

Provides methods for searching, fetching metadata, downloading subtitles,
and checking quota against the subs.ro v1.0 REST API.
"""

import json
from urllib.request import Request, urlopen
from urllib.parse import quote, urlencode
from urllib.error import HTTPError, URLError

from resources.lib import logger


class SubsRoAPIError(Exception):
    """Raised when the subs.ro API returns an error."""

    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code


class QuotaExceededError(SubsRoAPIError):
    """Raised when the daily download quota is exceeded."""
    pass


class SubsRoAPI:
    """
    Client for the subs.ro subtitle API v1.0.

    Usage:
        api = SubsRoAPI(api_key="your-key-here")
        results = api.search("imdbid", "tt1234567", language="ro")
        archive_bytes = api.download(results[0]["id"])
    """

    BASE_URL = "https://api.subs.ro/v1.0"
    TIMEOUT = 15  # seconds

    # Valid search fields accepted by the API
    VALID_SEARCH_FIELDS = ("imdbid", "tmdbid", "title", "release")

    # Valid language codes accepted by the API
    VALID_LANGUAGES = ("ro", "en", "ita", "fra", "ger", "ung", "gre", "por", "spa", "alt")

    def __init__(self, api_key):
        """
        Initialize the API client.

        Args:
            api_key: The subs.ro API key for authentication.
        """
        if not api_key:
            raise SubsRoAPIError("API key is required")
        self.api_key = api_key
        self._headers = {
            "X-Subs-Api-Key": api_key,
            "Accept": "application/json",
            "User-Agent": "Kodi/service.subtitles.subsro v1.0.0",
        }

    def _request(self, endpoint, expect_json=True):
        """
        Make an HTTP GET request to the API.

        Args:
            endpoint: The API endpoint path (appended to BASE_URL).
            expect_json: If True, parse response as JSON. If False, return raw bytes.

        Returns:
            Parsed JSON dict or raw bytes depending on expect_json.

        Raises:
            SubsRoAPIError: On HTTP errors or network failures.
            QuotaExceededError: On HTTP 429 (rate limit / quota exceeded).
        """
        url = "{base}{endpoint}".format(base=self.BASE_URL, endpoint=endpoint)
        logger.debug("API request: GET {url}".format(url=url))

        req = Request(url, headers=self._headers, method="GET")

        try:
            response = urlopen(req, timeout=self.TIMEOUT)
            data = response.read()

            if expect_json:
                decoded = data.decode("utf-8")
                result = json.loads(decoded)
                logger.debug(
                    "API response: status={status}, results={count}".format(
                        status=result.get("status", "unknown"),
                        count=len(result.get("results", [])),
                    )
                )
                return result
            else:
                logger.debug(
                    "API response: binary data, {size} bytes".format(size=len(data))
                )
                return data

        except HTTPError as e:
            status = e.code
            body = ""
            try:
                body = e.read().decode("utf-8", errors="replace")
            except Exception:
                pass

            if status == 429:
                raise QuotaExceededError(
                    "Daily download quota exceeded", status_code=429
                )
            elif status == 401:
                raise SubsRoAPIError("Invalid API key", status_code=401)
            elif status == 404:
                raise SubsRoAPIError(
                    "Resource not found: {endpoint}".format(endpoint=endpoint),
                    status_code=404,
                )
            else:
                raise SubsRoAPIError(
                    "HTTP {code}: {body}".format(code=status, body=body[:200]),
                    status_code=status,
                )

        except URLError as e:
            raise SubsRoAPIError("Network error: {reason}".format(reason=str(e.reason)))

        except Exception as e:
            raise SubsRoAPIError("Unexpected error: {err}".format(err=str(e)))

    def search(self, search_field, value, language=None):
        """
        Search for subtitles on subs.ro.

        Args:
            search_field: One of "imdbid", "tmdbid", "title", "release".
            value: The search value (e.g., "tt1234567" for imdbid).
            language: Optional language filter (e.g., "ro", "en").

        Returns:
            List of subtitle result dicts from the API, or empty list on failure.
        """
        if search_field not in self.VALID_SEARCH_FIELDS:
            logger.error(
                "Invalid search field: {field}. Must be one of: {valid}".format(
                    field=search_field,
                    valid=", ".join(self.VALID_SEARCH_FIELDS),
                )
            )
            return []

        if not value:
            logger.warning("Empty search value for field: {field}".format(field=search_field))
            return []

        # URL-encode the search value
        encoded_value = quote(str(value), safe="")
        endpoint = "/search/{field}/{value}".format(
            field=search_field, value=encoded_value
        )

        # Add language filter as query parameter
        if language and language in self.VALID_LANGUAGES:
            endpoint += "?{params}".format(params=urlencode({"language": language}))

        try:
            response = self._request(endpoint, expect_json=True)
            results = response.get("results", [])
            logger.info(
                "Search [{field}={value}]: {count} results found".format(
                    field=search_field, value=value, count=len(results)
                )
            )
            return results

        except SubsRoAPIError as e:
            logger.error("Search failed: {err}".format(err=str(e)))
            return []

    def get_subtitle(self, subtitle_id):
        """
        Get metadata for a specific subtitle.

        Args:
            subtitle_id: The subtitle ID from search results.

        Returns:
            Dict with subtitle metadata, or None on failure.
        """
        if not subtitle_id:
            return None

        endpoint = "/subtitle/{id}".format(id=quote(str(subtitle_id), safe=""))

        try:
            response = self._request(endpoint, expect_json=True)
            results = response.get("results", [])
            if results:
                return results[0] if isinstance(results, list) else results
            return None

        except SubsRoAPIError as e:
            logger.error(
                "Get subtitle {id} failed: {err}".format(id=subtitle_id, err=str(e))
            )
            return None

    def download(self, subtitle_id):
        """
        Download the subtitle archive (zip/rar) as raw bytes.

        Args:
            subtitle_id: The subtitle ID to download.

        Returns:
            Raw bytes of the archive file.

        Raises:
            SubsRoAPIError: On download failure.
            QuotaExceededError: If daily quota is exceeded.
        """
        if not subtitle_id:
            raise SubsRoAPIError("Subtitle ID is required for download")

        endpoint = "/subtitle/{id}/download".format(
            id=quote(str(subtitle_id), safe="")
        )
        return self._request(endpoint, expect_json=False)

    def check_quota(self):
        """
        Check remaining daily download quota.

        Returns:
            Dict with quota information, or None on failure.
        """
        try:
            response = self._request("/quota", expect_json=True)
            logger.info("Quota check: {resp}".format(resp=json.dumps(response)))
            return response

        except SubsRoAPIError as e:
            logger.error("Quota check failed: {err}".format(err=str(e)))
            return None
