# -*- coding: utf-8 -*-
"""
Archive extraction utilities for subtitle files.

Supports ZIP archives natively and RAR archives when the rarfile
library is available. Falls back to treating raw data as a plain
subtitle file if it is not a recognized archive format.
"""

import os
import zipfile
import io
import time

from resources.lib import logger

# Subtitle file extensions we look for inside archives
SUBTITLE_EXTENSIONS = (".srt", ".sub", ".ass", ".ssa", ".txt", ".smi")

# Try to import rarfile; it may not be available
try:
    import rarfile
    HAS_RARFILE = True
    logger.debug("rarfile library available - RAR support enabled")
except ImportError:
    HAS_RARFILE = False
    logger.debug("rarfile library not available - RAR support disabled")


def _find_subtitle_in_names(names):
    """
    Find the best subtitle file from a list of archive member names.

    Prioritizes .srt files, then other subtitle extensions.
    Ignores files in __MACOSX or hidden directories.

    Args:
        names: List of file name strings from the archive.

    Returns:
        The best matching file name, or None if no subtitle found.
    """
    candidates = []
    for name in names:
        # Skip macOS resource forks and hidden files
        if "__MACOSX" in name or name.startswith("."):
            continue
        basename = os.path.basename(name)
        if not basename:
            continue
        _, ext = os.path.splitext(basename.lower())
        if ext in SUBTITLE_EXTENSIONS:
            candidates.append((name, ext))

    if not candidates:
        return None

    # Prefer .srt, then .sub, then others
    priority = {".srt": 0, ".sub": 1, ".ass": 2, ".ssa": 3, ".txt": 4, ".smi": 5}
    candidates.sort(key=lambda item: priority.get(item[1], 99))

    return candidates[0][0]


def _ensure_dest_dir(dest_dir):
    """Create destination directory if it does not exist."""
    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir)


def _try_detect_encoding(data):
    """
    Attempt to detect text encoding of subtitle data.

    Romanian subtitles often use CP1250 or ISO-8859-2.
    Falls back through common encodings.

    Args:
        data: Raw bytes of subtitle content.

    Returns:
        Decoded string, attempting multiple encodings.
    """
    # Try chardet first if available
    try:
        import chardet
        detected = chardet.detect(data)
        if detected and detected.get("encoding"):
            encoding = detected["encoding"]
            logger.debug("chardet detected encoding: {enc}".format(enc=encoding))
            return data.decode(encoding)
    except ImportError:
        pass
    except Exception:
        pass

    # Manual fallback chain for Romanian subtitles
    encodings = ["utf-8", "utf-8-sig", "cp1250", "iso-8859-2", "iso-8859-1", "latin-1"]
    for enc in encodings:
        try:
            decoded = data.decode(enc)
            # Quick sanity check for Romanian diacritics
            logger.debug("Successfully decoded with: {enc}".format(enc=enc))
            return decoded
        except (UnicodeDecodeError, LookupError):
            continue

    # Last resort: decode with replacement characters
    return data.decode("utf-8", errors="replace")


def _write_subtitle_file(data, dest_path):
    """
    Write subtitle data to disk, re-encoding to UTF-8 if needed.

    Args:
        data: Raw bytes of the subtitle file.
        dest_path: Full path where the file should be written.

    Returns:
        The dest_path on success, None on failure.
    """
    try:
        text = _try_detect_encoding(data)
        # Write as UTF-8 with BOM for maximum compatibility
        with open(dest_path, "w", encoding="utf-8-sig") as f:
            f.write(text)
        logger.info("Subtitle written to: {path}".format(path=dest_path))
        return dest_path
    except Exception as e:
        logger.error(
            "Failed to write subtitle to {path}: {err}".format(
                path=dest_path, err=str(e)
            )
        )
        # Fallback: write raw bytes
        try:
            with open(dest_path, "wb") as f:
                f.write(data)
            return dest_path
        except Exception:
            return None


def _extract_from_zip(archive_bytes, dest_dir):
    """
    Extract subtitle from a ZIP archive.

    Args:
        archive_bytes: Raw bytes of the ZIP file.
        dest_dir: Directory to extract the subtitle into.

    Returns:
        Path to the extracted subtitle file, or None.
    """
    try:
        with zipfile.ZipFile(io.BytesIO(archive_bytes)) as zf:
            names = zf.namelist()
            logger.debug("ZIP contains {n} files: {files}".format(
                n=len(names), files=", ".join(names[:10])
            ))

            target = _find_subtitle_in_names(names)
            if not target:
                logger.warning("No subtitle file found in ZIP archive")
                return None

            data = zf.read(target)
            basename = os.path.basename(target)
            dest_path = os.path.join(dest_dir, basename)
            return _write_subtitle_file(data, dest_path)

    except zipfile.BadZipFile:
        logger.debug("Not a valid ZIP file")
        return None
    except Exception as e:
        logger.error("ZIP extraction error: {err}".format(err=str(e)))
        return None


def _extract_from_rar(archive_bytes, dest_dir):
    """
    Extract subtitle from a RAR archive using the rarfile library.

    Args:
        archive_bytes: Raw bytes of the RAR file.
        dest_dir: Directory to extract the subtitle into.

    Returns:
        Path to the extracted subtitle file, or None.
    """
    if not HAS_RARFILE:
        logger.warning(
            "RAR archive detected but rarfile library is not available. "
            "Install rarfile and unrar to support RAR archives."
        )
        return None

    # rarfile needs a file on disk, so write temporarily
    temp_rar = os.path.join(dest_dir, "_temp_archive.rar")
    try:
        with open(temp_rar, "wb") as f:
            f.write(archive_bytes)

        with rarfile.RarFile(temp_rar) as rf:
            names = rf.namelist()
            logger.debug("RAR contains {n} files: {files}".format(
                n=len(names), files=", ".join(names[:10])
            ))

            target = _find_subtitle_in_names(names)
            if not target:
                logger.warning("No subtitle file found in RAR archive")
                return None

            data = rf.read(target)
            basename = os.path.basename(target)
            dest_path = os.path.join(dest_dir, basename)
            return _write_subtitle_file(data, dest_path)

    except Exception as e:
        logger.error("RAR extraction error: {err}".format(err=str(e)))
        return None
    finally:
        # Clean up temp rar
        try:
            if os.path.exists(temp_rar):
                os.remove(temp_rar)
        except Exception:
            pass


def _try_as_plain_subtitle(data, dest_dir):
    """
    Treat raw bytes as a plain subtitle file (not inside an archive).

    Some APIs return the .srt directly instead of wrapping in an archive.

    Args:
        data: Raw bytes that might be a plain subtitle.
        dest_dir: Directory to write the file.

    Returns:
        Path to the written file, or None if data doesn't look like a subtitle.
    """
    # Quick heuristic: SRT files typically start with a number or BOM
    text_preview = data[:500].decode("utf-8", errors="replace").strip()
    # Check for SRT markers (numbered cue, timestamp arrow)
    if "-->" in text_preview or (text_preview and text_preview[0].isdigit()):
        logger.info("Data appears to be a plain SRT file (not archived)")
        dest_path = os.path.join(dest_dir, "subtitle.srt")
        return _write_subtitle_file(data, dest_path)

    # Check for SUB/SSA/ASS markers
    if "[Script Info]" in text_preview or "{0}" in text_preview:
        ext = ".ass" if "[Script Info]" in text_preview else ".sub"
        dest_path = os.path.join(dest_dir, "subtitle" + ext)
        return _write_subtitle_file(data, dest_path)

    return None


def extract_subtitle(archive_bytes, dest_dir):
    """
    Extract a subtitle file from archive bytes.

    Attempts extraction in this order:
    1. ZIP archive (native Python support)
    2. RAR archive (requires rarfile + unrar)
    3. Plain subtitle file (not archived)

    Args:
        archive_bytes: Raw bytes of the downloaded archive or subtitle file.
        dest_dir: Directory to extract the subtitle into. Created if needed.

    Returns:
        Absolute path to the extracted subtitle file, or None on failure.
    """
    if not archive_bytes:
        logger.error("No archive data to extract")
        return None

    _ensure_dest_dir(dest_dir)

    logger.debug(
        "Attempting to extract subtitle from {size} bytes to {dir}".format(
            size=len(archive_bytes), dir=dest_dir
        )
    )

    # Try ZIP first (most common)
    result = _extract_from_zip(archive_bytes, dest_dir)
    if result:
        return result

    # Try RAR
    result = _extract_from_rar(archive_bytes, dest_dir)
    if result:
        return result

    # Try as plain subtitle
    result = _try_as_plain_subtitle(archive_bytes, dest_dir)
    if result:
        return result

    logger.error("Could not extract any subtitle from the downloaded data")
    return None
