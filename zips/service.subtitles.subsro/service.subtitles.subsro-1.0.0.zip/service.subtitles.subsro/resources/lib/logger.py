# -*- coding: utf-8 -*-
"""
Logging utility for service.subtitles.subsro Kodi addon.

Wraps xbmc.log with addon-specific prefix and respects
the enable_logging setting for debug messages.
"""

import xbmc
import xbmcaddon

ADDON_ID = "service.subtitles.subsro"

# Log level mapping
LOG_DEBUG = xbmc.LOGDEBUG
LOG_INFO = xbmc.LOGINFO
LOG_WARNING = xbmc.LOGWARNING
LOG_ERROR = xbmc.LOGERROR


def _get_logging_enabled():
    """Check if debug logging is enabled in addon settings."""
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        return addon.getSettingBool("enable_logging")
    except Exception:
        return False


def _log(message, level=LOG_DEBUG):
    """
    Write a log message with addon prefix.

    Args:
        message: The message string to log.
        level: xbmc log level constant.
    """
    formatted = "[{addon}] {msg}".format(addon=ADDON_ID, msg=message)
    xbmc.log(formatted, level=level)


def debug(message):
    """Log a debug message (only if enable_logging is True in settings)."""
    if _get_logging_enabled():
        _log(message, LOG_DEBUG)


def info(message):
    """Log an info message (always logged regardless of setting)."""
    _log(message, LOG_INFO)


def warning(message):
    """Log a warning message."""
    _log(message, LOG_WARNING)


def error(message):
    """Log an error message."""
    _log(message, LOG_ERROR)
