#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Subs.ro Subtitle Addon for Kodi

Main entry point called by Kodi's subtitle search system.
Handles search, manualsearch, and download actions.

Kodi calls this script with:
    sys.argv[0] = plugin URL (e.g., "plugin://service.subtitles.subsro/")
    sys.argv[1] = handle (int for xbmcplugin calls)
    sys.argv[2] = query string (e.g., "?action=search&languages=English,Romanian")
"""

import sys
import os
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# Addon references
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
ADDON_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
TEMP_DIR = xbmcvfs.translatePath("special://temp/")

# Add addon lib path to sys.path
sys.path.insert(0, ADDON_PATH)

from resources.lib import logger
from resources.lib.subsro_api import SubsRoAPI, SubsRoAPIError, QuotaExceededError
from resources.lib.archive_utils import extract_subtitle
from resources.lib.kodi_utils import (
    get_media_info,
    get_kodi_languages,
    create_subtitle_listitem,
    notify,
    show_settings,
)

# Parse Kodi arguments
PLUGIN_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
PARAMS = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?")))


def _get_api():
    """
    Create and return a SubsRoAPI instance using the configured API key.

    Returns:
        SubsRoAPI instance, or None if no API key is set (shows settings dialog).
    """
    api_key = ADDON.getSetting("api_key")

    if not api_key or not api_key.strip():
        logger.warning("API key not configured")
        # Notify user and open settings
        notify(
            ADDON.getLocalizedString(32031)
            or "Please set your subs.ro API key in addon settings.",
            time=5000,
            icon=xbmcgui.NOTIFICATION_WARNING,
        )
        show_settings()
        return None

    return SubsRoAPI(api_key.strip())


def _filter_by_year(results, year):
    """
    Filter search results by year if available.

    Args:
        results: List of subtitle dicts from the API.
        year: Year string to filter by (e.g., "2023").

    Returns:
        Filtered list, or original list if year is empty or no matches.
    """
    if not year:
        return results

    try:
        target_year = int(year)
    except (ValueError, TypeError):
        return results

    filtered = [
        r for r in results
        if r.get("year") and abs(int(r.get("year", 0)) - target_year) <= 1
    ]

    # Return filtered if we got results, otherwise return all
    if filtered:
        logger.debug(
            "Year filter ({year}): {orig} -> {filtered} results".format(
                year=year, orig=len(results), filtered=len(filtered)
            )
        )
        return filtered

    return results


def _filter_tv_results(results, season, episode):
    """
    For TV shows, try to filter results matching season/episode.

    The subs.ro API may return all subtitles for a show.
    We try to find ones matching the specific episode based on
    description or title patterns like S01E02.

    Args:
        results: List of subtitle dicts.
        season: Season number string.
        episode: Episode number string.

    Returns:
        Filtered list, or original list if no episode-specific matches.
    """
    if not season or not episode:
        return results

    try:
        s_num = int(season)
        e_num = int(episode)
    except (ValueError, TypeError):
        return results

    # Build common patterns to match
    patterns = [
        "S{s:02d}E{e:02d}".format(s=s_num, e=e_num),
        "s{s:02d}e{e:02d}".format(s=s_num, e=e_num),
        "{s}x{e:02d}".format(s=s_num, e=e_num),
        "Season {s}".format(s=s_num),
        "Sezonul {s}".format(s=s_num),
    ]

    episode_matches = []
    season_matches = []

    for result in results:
        text = " ".join([
            result.get("title", ""),
            result.get("description", ""),
        ]).lower()

        # Check for exact episode match
        if any(p.lower() in text for p in patterns[:3]):
            episode_matches.append(result)
        # Check for season match
        elif any(p.lower() in text for p in patterns[3:]):
            season_matches.append(result)

    if episode_matches:
        logger.debug(
            "TV filter S{s:02d}E{e:02d}: {count} episode matches".format(
                s=s_num, e=e_num, count=len(episode_matches)
            )
        )
        return episode_matches

    if season_matches:
        logger.debug(
            "TV filter S{s:02d}: {count} season matches (no episode match)".format(
                s=s_num, count=len(season_matches)
            )
        )
        return season_matches

    return results


def search(params):
    """
    Search for subtitles based on currently playing media.

    Strategy:
    1. Try IMDB ID search (most accurate)
    2. Fall back to title search with year filtering
    3. Filter results by requested languages
    4. Display results to Kodi
    """
    api = _get_api()
    if not api:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    media = get_media_info()
    languages = get_kodi_languages(params)

    logger.info(
        "Search: title={title}, imdb={imdb}, year={year}, "
        "tv={is_tv}, season={season}, episode={episode}".format(
            title=media["title"],
            imdb=media["imdb_id"],
            year=media["year"],
            is_tv=media["is_tv"],
            season=media["season"],
            episode=media["episode"],
        )
    )

    all_results = []

    # Search for each requested language
    search_languages = languages if languages else [None]

    for lang in search_languages:
        results = []

        # Strategy 1: Search by IMDB ID (most accurate)
        if media["imdb_id"]:
            results = api.search("imdbid", media["imdb_id"], language=lang)
            if results:
                logger.info(
                    "IMDB search ({imdb}, lang={lang}): {count} results".format(
                        imdb=media["imdb_id"], lang=lang, count=len(results)
                    )
                )

        # Strategy 2: Fall back to title search
        if not results and media["title"]:
            results = api.search("title", media["title"], language=lang)
            if results:
                logger.info(
                    "Title search ({title}, lang={lang}): {count} results".format(
                        title=media["title"], lang=lang, count=len(results)
                    )
                )
                # Filter by year for title searches to improve accuracy
                results = _filter_by_year(results, media["year"])

        # Strategy 3: Try original title if different
        if not results and media["original_title"] and media["original_title"] != media["title"]:
            results = api.search("title", media["original_title"], language=lang)
            if results:
                results = _filter_by_year(results, media["year"])

        # Strategy 4: Try release name from filename
        if not results and media["filename"]:
            basename = os.path.basename(media["filename"])
            release_name = os.path.splitext(basename)[0]
            if release_name and len(release_name) > 3:
                results = api.search("release", release_name, language=lang)

        # For TV shows, filter by season/episode
        if media["is_tv"] and results:
            results = _filter_tv_results(
                results, media["season"], media["episode"]
            )

        # Add to combined results (avoid duplicates by ID)
        seen_ids = {r.get("id") for r in all_results}
        for result in results:
            if result.get("id") not in seen_ids:
                all_results.append(result)
                seen_ids.add(result.get("id"))

    # Display results
    if all_results:
        logger.info("Total results to display: {count}".format(count=len(all_results)))
        for subtitle in all_results:
            try:
                create_subtitle_listitem(subtitle, HANDLE, PLUGIN_URL)
            except Exception as e:
                logger.error(
                    "Error creating ListItem for subtitle {id}: {err}".format(
                        id=subtitle.get("id", "?"), err=str(e)
                    )
                )
    else:
        logger.info("No subtitles found")
        notify(
            ADDON.getLocalizedString(32032) or "No subtitles found",
            time=2000,
        )

    xbmcplugin.endOfDirectory(HANDLE)


def manual_search(params):
    """
    Search for subtitles using a manually entered title.

    Uses the searchstring parameter provided by Kodi when the user
    enters a manual search query.
    """
    api = _get_api()
    if not api:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    search_string = params.get("searchstring", "")
    if not search_string:
        logger.warning("Manual search called with empty search string")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    languages = get_kodi_languages(params)
    logger.info(
        "Manual search: query={query}, languages={langs}".format(
            query=search_string, langs=languages
        )
    )

    all_results = []
    search_languages = languages if languages else [None]

    for lang in search_languages:
        results = api.search("title", search_string, language=lang)

        # Also try as release name
        if not results:
            results = api.search("release", search_string, language=lang)

        # Add unique results
        seen_ids = {r.get("id") for r in all_results}
        for result in results:
            if result.get("id") not in seen_ids:
                all_results.append(result)
                seen_ids.add(result.get("id"))

    if all_results:
        logger.info(
            "Manual search results: {count}".format(count=len(all_results))
        )
        for subtitle in all_results:
            try:
                create_subtitle_listitem(subtitle, HANDLE, PLUGIN_URL)
            except Exception as e:
                logger.error(
                    "Error creating ListItem: {err}".format(err=str(e))
                )
    else:
        notify(
            ADDON.getLocalizedString(32032) or "No subtitles found",
            time=2000,
        )

    xbmcplugin.endOfDirectory(HANDLE)


def download(params):
    """
    Download the selected subtitle and return its path to Kodi.

    Flow:
    1. Download the archive from subs.ro API
    2. Extract the subtitle file (.srt/.sub) to a temp directory
    3. Return the extracted file path to Kodi via ListItem
    """
    api = _get_api()
    if not api:
        return

    subtitle_id = params.get("id", "")
    if not subtitle_id:
        logger.error("Download called without subtitle ID")
        notify(
            ADDON.getLocalizedString(32033) or "Download failed",
            icon=xbmcgui.NOTIFICATION_ERROR,
        )
        return

    logger.info("Downloading subtitle ID: {id}".format(id=subtitle_id))

    # Create a unique temp directory for this download
    timestamp = int(time.time() * 1000)
    dest_dir = os.path.join(TEMP_DIR, "subsro_{ts}".format(ts=timestamp))

    try:
        # Download the archive bytes
        archive_bytes = api.download(subtitle_id)

        if not archive_bytes:
            logger.error("Downloaded empty data for subtitle {id}".format(id=subtitle_id))
            notify(
                ADDON.getLocalizedString(32033) or "Download failed",
                icon=xbmcgui.NOTIFICATION_ERROR,
            )
            return

        logger.debug(
            "Downloaded {size} bytes for subtitle {id}".format(
                size=len(archive_bytes), id=subtitle_id
            )
        )

        # Extract subtitle from archive
        subtitle_path = extract_subtitle(archive_bytes, dest_dir)

        if not subtitle_path:
            logger.error(
                "Could not extract subtitle from archive for ID {id}".format(
                    id=subtitle_id
                )
            )
            notify(
                ADDON.getLocalizedString(32035)
                or "Could not extract subtitle from archive",
                icon=xbmcgui.NOTIFICATION_ERROR,
            )
            return

        logger.info("Subtitle extracted to: {path}".format(path=subtitle_path))

        # Return the subtitle path to Kodi
        listitem = xbmcgui.ListItem(label=os.path.basename(subtitle_path))
        xbmcplugin.addDirectoryItem(
            handle=HANDLE,
            url=subtitle_path,
            listitem=listitem,
            isFolder=False,
        )
        xbmcplugin.endOfDirectory(HANDLE)

    except QuotaExceededError:
        logger.warning("Daily download quota exceeded")
        notify(
            ADDON.getLocalizedString(32034) or "Daily quota exceeded",
            time=5000,
            icon=xbmcgui.NOTIFICATION_WARNING,
        )

    except SubsRoAPIError as e:
        logger.error("API error during download: {err}".format(err=str(e)))
        notify(
            ADDON.getLocalizedString(32033) or "Download failed",
            icon=xbmcgui.NOTIFICATION_ERROR,
        )

    except Exception as e:
        logger.error("Unexpected error during download: {err}".format(err=str(e)))
        notify(
            ADDON.getLocalizedString(32033) or "Download failed",
            icon=xbmcgui.NOTIFICATION_ERROR,
        )


def main():
    """
    Main entry point. Routes to the appropriate action handler
    based on the 'action' parameter from Kodi.
    """
    action = PARAMS.get("action", "search")

    logger.info(
        "Addon called: action={action}, params={params}".format(
            action=action, params=str(PARAMS)
        )
    )

    if action == "search":
        search(PARAMS)
    elif action == "manualsearch":
        manual_search(PARAMS)
    elif action == "download":
        download(PARAMS)
    else:
        logger.warning("Unknown action: {action}".format(action=action))
        xbmcplugin.endOfDirectory(HANDLE)


if __name__ == "__main__":
    main()
